#ifndef X_BUTTONS_H
#define X_BUTTONS_H

// Include any necessary headers here

// Define any constants or macros here

// Declare any global variables here

// Declare any function prototypes here
void X_ButtonsInit(void);
void X_ReadButtons(void);
int X_ButtonState(int num);

#endif // X_BUTTONS_H

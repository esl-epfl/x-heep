#ifndef X_DISPLAY_H
#define X_DISPLAY_H


void X_Display_init(void);
//void X_Display_Draw_ScreenBuffer(void);
void X_Display_Draw_Screen_200x200(void);




#endif // X_DISPLAY_H
